public class PilhaDePratos {
    private int[] pratos;
    private int topo;
    private int capacidade;

    public PilhaDePratos(int capacidade) {
        this.capacidade = capacidade;
        pratos = new int[capacidade];
        topo = -1;
    }

    public void push(int prato) throws PilhaCheiaException {
        if (isFull()) {
            throw new PilhaCheiaException("Pilha cheia! Não é possível adicionar mais pratos.");
        }
        pratos[++topo] = prato;
    }

    public int pop() throws PilhaVaziaException {
        if (isEmpty()) {
            throw new PilhaVaziaException("Pilha vazia! Não há pratos para remover.");
        }
        return pratos[topo--];
    }

    public int peek() throws PilhaVaziaException {
        if (isEmpty()) {
            throw new PilhaVaziaException("Pilha vazia! Não há pratos no topo.");
        }
        return pratos[topo];
    }

    public boolean isEmpty() {
        return topo == -1;
    }

    public boolean isFull() {
        return topo == capacidade - 1;
    }

    public int tamanho() {
        return topo + 1;
    }

    public void limpar() {
        topo = -1;
    }

    public void mostrarPilha() {
        if (isEmpty()) {
            System.out.println("Pilha vazia.");
            return;
        }
        System.out.print("Estado da pilha (do topo para base): ");
        for (int i = topo; i >= 0; i--) {
            System.out.print(pratos[i] + " ");
        }
        System.out.println();
    }
}
