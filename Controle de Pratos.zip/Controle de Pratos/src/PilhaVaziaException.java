public class PilhaVaziaException extends Exception {
    public PilhaVaziaException(String mensagem) {
        super(mensagem);
    }
}
