public class PilhaCheiaException extends Exception {
    public PilhaCheiaException(String mensagem) {
        super(mensagem);
    }
}
